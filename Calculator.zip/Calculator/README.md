# Calculator 
Merupakan contoh kalkulator sederhana dengan menggunakan HTML, CSS, dan JavaScript untuk memenuhi Tugas 

